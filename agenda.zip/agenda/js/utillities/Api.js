class API {
    dataFromAPI = [];


    async getData() {
        await fetch("../data/data.json").then(Response => {
            return Response.json();
        }).then(data => {
            this.dataFromAPI = data.months;
        });
        return this.dataFromAPI;
    }
}