class Renderer{
    render(placeToRender, whatToRender){
       document.querySelector(placeToRender).appendChild(whatToRender);
    }
   
   }